package Project;
import java.util.Scanner;
public class login 
{
	public static boolean happy()
    {
        String username, password;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter username:");
        username = s.nextLine();
        System.out.print("Enter password:");
        password = s.nextLine();
        if(username.equals("user") && password.equals("user"))
        {
            System.out.println("Authentication Successful\n");
            return true;
        }
        else
        {
            System.out.println("Authentication Failed\n");
            return false;
        }
        
    }
}
